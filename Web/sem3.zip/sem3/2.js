


function greeting(userName) {
    alert(`Рад знакомству, ${userName}!`)
}

greeting(prompt('Прошу, представьтесь.'))